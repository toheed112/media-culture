package dev.techwisers.Media.Culture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaCultureApplicationTests {

	@Test
	void contextLoads() {
	}

}
